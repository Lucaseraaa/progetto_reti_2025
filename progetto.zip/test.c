#include "stdio.h"
#include <stdlib.h>
#include "string.h"
#include "time.h"
#include "structs/enums.h"
#include "classes/board.h"
#include "functions/functions_board.h"
#include "server/connection.h"

#define ID 1

int main(){

    select_main();

    return 0;

}